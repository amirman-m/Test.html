import nltk
import numpy as np
nltk.download('punkt')
from nltk.stem.porter import PorterStemmer
stemer=PorterStemmer()
def tokensize(sentece):
    return nltk.word_tokenize(sentece)

def stem(word):
    return stemer.stem(word.lower())

def bag_of_words(tokenized_sentence, words):
    tokenized_sentence = [stem(w) for w in tokenized_sentence]
    word_list=np.zeros(len(words), dtype=np.float32)
    for idx , w in enumerate(words):
        if w in tokenized_sentence:
            word_list[idx]=1.0

    return word_list

#w= ["'s", 'a', 'accept', 'anyon', 'are', 'bye', 'can', 'card', 'cash', 'credit', 'day', 'deliveri', 'do', 'doe', 'funni', 'get', 'good', 'goodby', 'have', 'hello', 'help', 'hey', 'hi', 'how', 'i', 'is', 'item', 'joke', 'kind', 'know', 'later', 'long', 'lot', 'mastercard', 'me', 'my', 'of', 'onli', 'pay', 'paypal', 'see', 'sell', 'ship', 'someth', 'take', 'tell', 'thank', 'that', 'there', 'what', 'when', 'which', 'with', 'you']
#t=["how","are","you"]
#print(bag_of_words(t,w))


